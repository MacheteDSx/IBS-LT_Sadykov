Reg()
{

	lr_start_transaction("GotoWebTours");

	web_add_cookie("12-Dec-2024 17:04:44 GMT; DOMAIN=localhost");

	web_add_cookie("MSO=SID&1734109484; DOMAIN=localhost");

	web_add_cookie("MTUserInfo=; DOMAIN=localhost");

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GotoWebTours",LR_AUTO);

	lr_start_transaction("ToSignUp");

	web_add_cookie("12-Dec-2024 17:06:11 GMT; DOMAIN=localhost");

	web_add_cookie("MSO=SID&1734109571; DOMAIN=localhost");

	lr_think_time(33);

	web_url("login.pl", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/home.html", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ToSignUp",LR_AUTO);

	lr_start_transaction("ToContinueSignUp");

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	lr_think_time(53);

	web_submit_form("login.pl_2", 
		"Snapshot=t19.inf", 
		ITEMDATA, 
		"Name=username", "Value=User1", ENDITEM, 
		"Name=password", "Value=qwer1234", ENDITEM, 
		"Name=passwordConfirm", "Value=qwer1234", ENDITEM, 
		"Name=firstName", "Value=Name", ENDITEM, 
		"Name=lastName", "Value=Last", ENDITEM, 
		"Name=address1", "Value=Street", ENDITEM, 
		"Name=address2", "Value=City", ENDITEM, 
		"Name=password", "Value=", ENDITEM, 
		"Name=passwordConfirm", "Value=", ENDITEM, 
		"Name=firstName", "Value=", ENDITEM, 
		"Name=lastName", "Value=", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ToContinueSignUp",LR_AUTO);

	lr_think_time(9);

	web_submit_form("login.pl_3", 
		"Snapshot=t20.inf", 
		ITEMDATA, 
		"Name=username", "Value=User1", ENDITEM, 
		"Name=password", "Value=qwer1234", ENDITEM, 
		"Name=passwordConfirm", "Value=qwer1234", ENDITEM, 
		"Name=firstName", "Value=Name", ENDITEM, 
		"Name=lastName", "Value=Last", ENDITEM, 
		"Name=address1", "Value=Street", ENDITEM, 
		"Name=address2", "Value=City", ENDITEM, 
		"Name=password", "Value=", ENDITEM, 
		"Name=passwordConfirm", "Value=", ENDITEM, 
		"Name=firstName", "Value=", ENDITEM, 
		"Name=lastName", "Value=", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		LAST);

	lr_start_transaction("ThankYouForRegister");

	web_revert_auto_header("Origin");

	lr_think_time(45);

	web_image("button_next.gif", 
		"Src=/WebTours/images/button_next.gif", 
		"Snapshot=t21.inf", 
		LAST);

	lr_end_transaction("ThankYouForRegister",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("Logout");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t22.inf", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}