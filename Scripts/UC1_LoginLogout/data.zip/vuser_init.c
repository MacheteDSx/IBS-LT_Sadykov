/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 911
   ------------------------------------------------------------------------------- */

vuser_init()
{

	lr_start_transaction("GoToWebTours");

	web_add_cookie("07-Dec-2024 16:26:23 GMT; DOMAIN=localhost");

	web_add_cookie("MSO=SID&1733675183; DOMAIN=localhost");

	web_add_cookie("MTUserInfo=; DOMAIN=localhost");

	web_add_header("Priority", 
		"u=4");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("GoToWebTours",LR_AUTO);

	return 0;
}
